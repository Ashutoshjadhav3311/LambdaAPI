import express from 'express';
import translate from 'translate';

import cors from 'cors';

const app = express();
const port = 3000;

// Middleware to parse JSON requests
app.use(express.json());
// Enable CORS
app.use(cors());

// Handle CORS preflight requests
app.options('*', cors());

// Endpoint for translation
app.post('/translate', async (req, res) => {
  try {
    const { text, to } = req.body;
    if (!text || !to) {
      return res.status(400).json({ error: 'Missing required parameters' });
    }

    const translatedText = await translate(text, { to });
    res.json({ translatedText });
  } catch (error) {
    console.error('Translation error:', error);
    res.status(500).json({ error: 'An error occurred during translation' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
